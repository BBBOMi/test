package e2017.exam1;

public class Example11 {
    static void printSum(int... a) { 
    	int sum = 0;
    	System.out.printf("�迭:[");
    	for(int i : a) {
    		System.out.printf("%d ", i);
    		sum += i;
    	}
    	System.out.printf("] �հ�:%d", sum);
    	System.out.println();
    } 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int[] a = new int[] { 21, 33, 17, 40, 5, 13 }; 

        printSum( 11, 13, 17, 20 ); 
        printSum( a ); 
	}

}
