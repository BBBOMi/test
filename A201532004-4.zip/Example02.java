package e2017.exam1;

public class Example02 {
    static int countVowel(String s) { 
    	String s1 = s.toLowerCase();
		char[] arr = s1.toCharArray();
		int c = 0;
		
		for(char ch : arr) {
			if(ch == 97 || ch == 101 || ch == 105 || ch == 111 || ch == 117)
				c++;
		}
    	return c;
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String[] a = { "hello", "1234", "HELLO world", "aeiou AEIOU" }; 
        for (String s : a) 
            System.out.printf("%d ", countVowel(s)); 

	}

}
