package e2017.exam1;

public class Example03 {
	static void countVowel(String s, int[] count) {
		String s1 = s.toLowerCase();
		char[] arr = s1.toCharArray();
		int a=0, e=0, i=0, o=0, u=0;

		for(char ch : arr) {
			if(ch == 97) {
				a++;
				count[0] = a;
			}
			if(ch == 101) {
				e++;
				count[1] = e;
			}
			if(ch == 105) {
				i++;
				count[2] = i;
			}
			if(ch == 111) {
				o++;
				count[3] = o;
			}
			if(ch == 117) {
				u++;
				count[4] = u;
			}
		}

	}




	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] a = { "hello", "1234", "HELLO world", "aeiou AEIOU" }; 
		int[] count = new int[5]; 
		System.out.println("A E I O U"); 
		System.out.println("---------"); 
		for (String s : a) { 
			countVowel(s, count); 
			System.out.printf("%d %d %d %d %d %s\n", count[0], count[1], count[2], count[3], count[4], s); 
		}

	}

}
